detials = {
    "name":"Roham",
    "age":18,
    "grade":"A"

}

# epmty dic
new = dict()
print(detials)

for i in detials:
    print(i,detials[i])
