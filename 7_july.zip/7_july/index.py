# 1. Varibales 
# 2. Data types
# 3. Sequence data types / data structure 
# range 
