age = (10,18)
num = tuple()
# age[0] = 19
# count, index, len 

update_age = list(age)
print(update_age)

num1 = (10,)
print(type(num1))
