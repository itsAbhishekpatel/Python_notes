# unordered 
num = {1,3,4,5,6,6}

num1 = set()
print(num)
print(type(num1))


