name = ["Jie","Aman",18,True]
# print(name,type(name))
# upated_student = ["John"]

# name.append("new_value")
# name.extend(upated_student)

# print(name.pop(0))

# print(name)

# # name = list()
a,b,c,d = name

"""Hey how\'re you
 "Abihshek"."""
# print(text)