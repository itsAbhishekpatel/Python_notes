import math

age = 18 # int
price = 50.5
name = "Rohan" #str 
status = True # bool
num_complex = 2 + 3j

print(f"Age : {type(age)},name: {name}")

# expression 
# PEMDAS
a = 10 / (6 + 3) 
print(a)

# assignment 
city = "Delhi"
num = 10
num = num + 1 # num += 1

a,b,c = 10,20,40
a = b = c = 20

number = 25
print(int(math.sqrt(number)))

# print("Hello","World",sep="-",end="*")
# print("Hey")


